/** MISEN V7 — tailwind.config.js (as specified in MISEN_V7_DESIGN_SYSTEM) */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        dark: { 950:'#06080D', 900:'#0C0F1A', 850:'#111827', 800:'#1A1F2E',
                700:'#252B3B', 600:'#374151', 500:'#4B5563', 400:'#6B7280', 300:'#9CA3AF' },
        orange: { 50:'#FFF7ED', 100:'#FFEDD5', 200:'#FED7AA', 300:'#FDBA74',
                  400:'#FB923C', 500:'#F97316', 600:'#EA580C', 700:'#C2410C',
                  800:'#9A3412', 900:'#7C2D12' },
        gold: { 50:'#FFFBEB', 100:'#FEF3C7', 200:'#FDE68A', 300:'#FCD34D',
                400:'#FBBF24', 500:'#D4A853', 600:'#B8860B' },
      },
      fontFamily: {
        serif: ['DM Serif Display', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      boxShadow: {
        'glow-orange': '0 0 20px rgba(249,115,22,0.15)',
        'glow-gold': '0 0 20px rgba(251,191,36,0.15)',
      },
    },
  },
}
